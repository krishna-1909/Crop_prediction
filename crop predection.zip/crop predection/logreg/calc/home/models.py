from django.db import models

# Create your models here.
class store(models.Model):
    climate=models.CharField(blank=True,max_length=50)
    croptype = models.CharField(blank=True,max_length=50)
    watersupply = models.IntegerField(blank=True,max_length=50)
    soiltype= models.CharField(blank=True,max_length=50)
    quality = models.IntegerField(default=1)
    rating=models.IntegerField(default=5)
    def __str__(self):
        return self.croptype
