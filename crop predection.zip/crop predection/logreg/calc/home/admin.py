from django.contrib import admin
from home.models import store
admin.site.register(store)
# Register your models here.
